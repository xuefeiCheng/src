Place here your custom modules. You can drop all your JS files or create a folder for all your controllers, directives, etc. 
Another better approach is to create a folder for each model in your application.

All files here will be concatenated after all files in the modules/ folder.

Dependencies, see file app.init.js
Routes, see file modules/config.js
Constants, see file modules/constant.js

